package com.shapira.examples.streams.clickstreamenrich.model;

/**
 * Created by gwen on 1/28/17.
 */
public class UserWindow {
    int userID;
    long timestamp;
}
